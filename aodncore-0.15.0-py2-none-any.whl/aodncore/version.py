"""Contains the current version tag, stored in the module level variable '__version__'.
Updated automatically by the build server
"""

__version__ = '0.15.0'
